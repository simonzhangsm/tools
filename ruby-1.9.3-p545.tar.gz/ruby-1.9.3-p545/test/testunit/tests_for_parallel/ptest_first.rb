require 'test/unit'

class TestA < Test::Unit::TestCase
  def test_nothing_test
  end
end

