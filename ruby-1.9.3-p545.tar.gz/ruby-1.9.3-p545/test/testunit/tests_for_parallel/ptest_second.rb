require 'test/unit'

class TestB < Test::Unit::TestCase
  def test_nothing
  end
end

class TestC < Test::Unit::TestCase
  def test_nothing
  end
end
