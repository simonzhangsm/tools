# -*- coding: utf-8 -*-

require File.join(File.dirname(__FILE__), 'cfpropertylist', 'lib', 'rbCFPropertyList.rb')


# eof
