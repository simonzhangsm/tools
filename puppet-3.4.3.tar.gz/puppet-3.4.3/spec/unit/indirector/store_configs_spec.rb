#! /usr/bin/env ruby
require 'spec_helper'

require 'puppet/indirector/store_configs'

describe Puppet::Indirector::StoreConfigs do
  pending "REVISIT: creating an instance requires ludicrous amounts of stubbing, and there is relatively little to actually test here.  What to do?  Shared behaviours allow us to push down a lot of the testing into the implementation class tests anyhow..."
end
