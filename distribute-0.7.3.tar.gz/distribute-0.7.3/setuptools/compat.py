import sys
import itertools

if sys.version_info[0] < 3:
    PY3 = False

    str = str
    import builtins as builtins
    import configparser
    from io import StringIO
    BytesIO = StringIO
    execfile = execfile
    func_code = lambda o: o.__code__
    func_globals = lambda o: o.__globals__
    im_func = lambda o: o.__func__
    from html.entities import name2codepoint
    import http.client
    from http.server import HTTPServer
    from http.server import SimpleHTTPRequestHandler
    from http.server import BaseHTTPRequestHandler
    iteritems = lambda o: iter(list(o.items()))
    long_type = int
    maxsize = sys.maxsize
    next = lambda o: o.__next__()
    numeric_types = (int, int, float)
    reduce = reduce
    chr = chr
    str = str
    from urllib.request import url2pathname
    import urllib.request, urllib.error, urllib.parse
    from urllib.request import urlopen
    from urllib.error import HTTPError, URLError
    from urllib.parse import unquote, splituser
    from urllib.parse import urlparse, urlunparse, urljoin
    xrange = xrange
    filterfalse = itertools.ifilterfalse

    def exec_(code, globs=None, locs=None):
        if globs is None:
            frame = sys._getframe(1)
            globs = frame.f_globals
            if locs is None:
                locs = frame.f_locals
            del frame
        elif locs is None:
            locs = globs
        exec("""exec code in globs, locs""")

    exec_("""def reraise(tp, value, tb=None):
    raise tp, value, tb""")
else:
    PY3 = True

    str = str
    import builtins
    import configparser as ConfigParser
    exec_ = eval('exec')
    from io import StringIO, BytesIO
    func_code = lambda o: o.__code__
    func_globals = lambda o: o.__globals__
    im_func = lambda o: o.__func__
    from html.entities import name2codepoint
    import http.client as httplib
    from http.server import HTTPServer, SimpleHTTPRequestHandler
    from http.server import BaseHTTPRequestHandler
    iteritems = lambda o: list(o.items())
    long_type = int
    maxsize = sys.maxsize
    next = next
    numeric_types = (int, float)
    from functools import reduce
    chr = chr
    str = str
    from urllib.error import HTTPError, URLError
    import urllib.request as urllib2
    from urllib.request import urlopen, url2pathname
    from urllib.parse import urlparse, urlunparse, unquote, splituser, urljoin
    xrange = range
    filterfalse = itertools.filterfalse

    def execfile(fn, globs=None, locs=None):
        if globs is None:
            globs = globals()
        if locs is None:
            locs = globs
        f = open(fn)
        try:
            source = f.read()
        finally:
            f.close()
        exec_(compile(source, fn, 'exec'), globs, locs)

    def reraise(tp, value, tb=None):
        if value.__traceback__ is not tb:
            raise value.with_traceback(tb)
        raise value
